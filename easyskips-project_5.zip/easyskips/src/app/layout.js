"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Truck, FileText, AlertCircle, BarChart2,
  Settings, LogOut, ChevronDown, Search, Plus, Bell,
  TrendingUp, Users, ChevronRight, Menu, X
} from "lucide-react";
import "./globals.css";

const NAV = [
  { icon: LayoutDashboard, label: "Overview",        href: "/",          active: true  },
  { icon: Truck,           label: "Fleet Mgmt",      href: "/fleet",     dropdown: true },
  { icon: FileText,        label: "Invoices",         href: "/invoices",  tag: "New"    },
  { icon: AlertCircle,     label: "Debtors",          href: "/debtors",   badge: 5      },
  { icon: BarChart2,       label: "Analytics",        href: "/analytics", dropdown: true },
  { icon: Users,           label: "Clients",          href: "/clients"                  },
];

const BOTTOM = [
  { icon: Settings, label: "Settings", href: "/settings" },
  { icon: LogOut,   label: "Log Out",  href: "/logout",  danger: true },
];

function NavItem({ item, active, collapsed }) {
  return (
    <Link href={item.href}
      className={`
        flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
        transition-all duration-200 group relative
        ${active
          ? "bg-gradient-to-r from-[#7C5CFC] to-[#5A3FD0] text-white shadow-lg shadow-[#7C5CFC]/20"
          : "text-[#6B7280] hover:text-[#D1D5DB] hover:bg-[#1C1C26]"
        }
      `}
    >
      <item.icon size={17} className={active ? "text-white" : "text-[#6B7280] group-hover:text-[#D1D5DB]"} />
      {!collapsed && (
        <>
          <span className="flex-1 truncate">{item.label}</span>
          {item.badge && (
            <span className="text-[10px] font-bold bg-[#F87171] text-white px-2 py-0.5 rounded-full">
              {item.badge}
            </span>
          )}
          {item.tag && (
            <span className="text-[9px] font-bold bg-[#7C5CFC]/20 text-[#A78BFA] px-2 py-0.5 rounded-full uppercase tracking-wider">
              {item.tag}
            </span>
          )}
          {item.dropdown && <ChevronDown size={13} className="opacity-40" />}
        </>
      )}
    </Link>
  );
}

export default function RootLayout({ children }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={`flex items-center gap-3 mb-8 px-1 ${collapsed ? "justify-center" : ""}`}>
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#C97010] to-[#E88B1A] flex items-center justify-center text-sm font-bold text-white shadow-md flex-shrink-0">
          ES
        </div>
        {!collapsed && (
          <span className="text-[17px] font-bold tracking-tight">
            easy<span className="text-[#C97010]">skips</span>
          </span>
        )}
      </div>

      {/* Main nav */}
      {!collapsed && (
        <p className="text-[10px] font-semibold uppercase tracking-widest text-[#3D4460] px-3 mb-3">
          Main Menu
        </p>
      )}
      <nav className="flex flex-col gap-1 mb-6">
        {NAV.map(item => (
          <NavItem key={item.href} item={item} active={pathname === item.href} collapsed={collapsed} />
        ))}
      </nav>

      {/* Divider */}
      <div className="border-t border-[#1F2233] my-2" />

      {!collapsed && (
        <p className="text-[10px] font-semibold uppercase tracking-widest text-[#3D4460] px-3 mb-3 mt-3">
          System
        </p>
      )}
      <nav className="flex flex-col gap-1">
        {BOTTOM.map(item => (
          <Link key={item.href} href={item.href}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
              ${item.danger ? "text-[#F87171] hover:bg-[#F87171]/10" : "text-[#6B7280] hover:text-[#D1D5DB] hover:bg-[#1C1C26]"}`}
          >
            <item.icon size={17} />
            {!collapsed && <span>{item.label}</span>}
          </Link>
        ))}
      </nav>

      {/* Collapse toggle */}
      <button onClick={() => setCollapsed(!collapsed)}
        className="mt-auto flex items-center justify-center w-full py-2 text-[#3D4460] hover:text-[#6B7280] transition-colors"
      >
        <ChevronRight size={16} className={`transition-transform duration-300 ${collapsed ? "rotate-0" : "rotate-180"}`} />
      </button>
    </div>
  );

  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-[#13131A] text-[#F0F2F8] min-h-screen">
        <div className="flex min-h-screen">

          {/* ── SIDEBAR ── */}
          <aside className={`
            fixed top-0 left-0 h-full z-40 hidden md:flex flex-col
            bg-[#0E0F17] border-r border-[#1C1C2E]
            transition-all duration-300
            ${collapsed ? "w-[68px]" : "w-[240px]"}
          `}>
            <div className="flex-1 overflow-y-auto px-3 py-6">
              {sidebarContent}
            </div>
          </aside>

          {/* ── MOBILE OVERLAY ── */}
          {mobileOpen && (
            <div className="fixed inset-0 z-50 md:hidden">
              <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
              <aside className="absolute left-0 top-0 h-full w-[240px] bg-[#0E0F17] border-r border-[#1C1C2E] px-3 py-6">
                {sidebarContent}
              </aside>
            </div>
          )}

          {/* ── MAIN AREA ── */}
          <div className={`flex-1 flex flex-col transition-all duration-300 ${collapsed ? "md:ml-[68px]" : "md:ml-[240px]"}`}>

            {/* ── TOP HEADER ── */}
            <header className="sticky top-0 z-30 flex items-center justify-between gap-4
              px-6 h-[68px] bg-[#13131A]/90 backdrop-blur-xl border-b border-[#1C1C2E]">

              <button className="md:hidden text-[#6B7280]" onClick={() => setMobileOpen(true)}>
                <Menu size={22} />
              </button>

              {/* Search */}
              <div className="flex-1 max-w-[400px] relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#3D4460]" />
                <input
                  type="text"
                  placeholder="Search invoices, clients, skips..."
                  className="w-full bg-[#1C1C26] border border-[#2A2A3E] rounded-xl pl-9 pr-4 py-2.5 text-sm text-[#D1D5DB] placeholder-[#3D4460] outline-none focus:border-[#7C5CFC]/50 transition-colors"
                />
              </div>

              {/* Right */}
              <div className="flex items-center gap-3">
                <button className="relative p-2.5 bg-[#1C1C26] border border-[#2A2A3E] rounded-xl text-[#6B7280] hover:text-[#D1D5DB] transition-colors">
                  <Bell size={17} />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#F87171] rounded-full" />
                </button>
                <button className="flex items-center gap-2 bg-gradient-to-r from-[#C97010] to-[#E88B1A] hover:opacity-90 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition-opacity shadow-md shadow-[#C97010]/25">
                  <Plus size={16} />
                  <span className="hidden sm:inline">New Invoice</span>
                </button>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#7C5CFC] to-[#5A3FD0] flex items-center justify-center text-[11px] font-bold text-white">
                  OP
                </div>
              </div>
            </header>

            {/* ── PAGE CONTENT ── */}
            <main className="flex-1 overflow-auto">
              {children}
            </main>
          </div>
        </div>
      </body>
    </html>
  );
}
