"use client";
import { useState, useMemo } from "react";
import { Users, TrendingUp, Award, Clock, Search, Star, Phone, Mail } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, AreaChart, Area } from "recharts";

const ALL_INVOICES = [
  { client:"Buco Cash",      date:"2026-05-28", amount:1350, banked:1350, hire:"Weekly"  },
  { client:"Euro Sales",     date:"2026-05-26", amount:1600, banked:0,    hire:"Monthly" },
  { client:"Shelly Park",    date:"2026-05-22", amount:2700, banked:2700, hire:"Weekly"  },
  { client:"Willie EFT",     date:"2026-05-18", amount:2250, banked:2250, hire:"Weekly"  },
  { client:"Eloftus Lodge",  date:"2026-04-28", amount:1200, banked:0,    hire:"Monthly" },
  { client:"Lesego Builds",  date:"2026-04-15", amount:850,  banked:850,  hire:"Daily"   },
  { client:"Jaco EFT",       date:"2026-04-10", amount:1800, banked:1800, hire:"Weekly"  },
  { client:"Pink Rocks",     date:"2026-03-20", amount:2700, banked:2700, hire:"Monthly" },
  { client:"Air Products",   date:"2026-03-15", amount:1800, banked:1800, hire:"Weekly"  },
  { client:"RHS Hoer Skool", date:"2026-02-20", amount:700,  banked:700,  hire:"Daily"   },
  { client:"Buco Cash",      date:"2026-01-15", amount:1350, banked:1350, hire:"Weekly"  },
  { client:"Brigadoon",      date:"2025-12-10", amount:1200, banked:900,  hire:"Monthly" },
  { client:"Euro Sales",     date:"2025-11-20", amount:1800, banked:1800, hire:"Monthly" },
  { client:"Willie EFT",     date:"2025-10-15", amount:1800, banked:1800, hire:"Weekly"  },
  { client:"Crane Corp",     date:"2025-09-20", amount:4200, banked:4200, hire:"Monthly" },
  { client:"Shelly Park",    date:"2025-08-14", amount:2250, banked:2250, hire:"Weekly"  },
  { client:"Concept Mining", date:"2025-07-10", amount:4500, banked:4500, hire:"Monthly" },
  { client:"Eloftus Lodge",  date:"2026-04-01", amount:900,  banked:0,    hire:"Monthly" },
  { client:"Brigadoon",      date:"2026-02-14", amount:750,  banked:0,    hire:"Weekly"  },
];

function daysSince(d) { return Math.floor((Date.now() - new Date(d)) / 86400000); }

function buildClients(invs) {
  const map = {};
  const firstSeen = {};
  invs.forEach(i => {
    if (!firstSeen[i.client] || i.date < firstSeen[i.client]) firstSeen[i.client] = i.date;
  });
  invs.forEach(i => {
    if (!map[i.client]) map[i.client] = { name:i.client, jobs:0, revenue:0, banked:0, last:"", first:firstSeen[i.client] };
    map[i.client].jobs++;
    map[i.client].revenue += i.amount;
    map[i.client].banked += i.banked;
    if (!map[i.client].last || i.date > map[i.client].last) map[i.client].last = i.date;
  });
  return Object.values(map).map(c => ({
    ...c,
    outstanding: c.revenue - c.banked,
    avgInvoice: Math.round(c.revenue / c.jobs),
    daysSinceLast: daysSince(c.last),
    isNew: firstSeen[c.name] >= "2026-04-01",
    status: daysSince(c.last) <= 30 ? "Active" : daysSince(c.last) <= 90 ? "Recent" : "Lapsed",
    isRepeat: invs.filter(i => i.client === c.name).length > 1,
  })).sort((a,b) => b.revenue - a.revenue);
}

const clients = buildClients(ALL_INVOICES);

const topClientBars = clients.slice(0,6).map(c => ({ name: c.name.split(" ")[0], revenue: c.revenue }));
const barColors = ["#C97010","#7C5CFC","#00E676","#2DD4BF","#F472B6","#FBBF24"];

const newVsRepeat = [
  { month:"Feb", newRev:1450, repeatRev:3200 },
  { month:"Mar", newRev:2100, repeatRev:4100 },
  { month:"Apr", newRev:850,  repeatRev:4750 },
  { month:"May", newRev:2700, repeatRev:5200 },
];

function StatusBadge({ status }) {
  const cfg = { Active:"bg-[#00E676]/10 text-[#00E676]", Recent:"bg-[#FBBF24]/10 text-[#FBBF24]", Lapsed:"bg-[#F87171]/10 text-[#F87171]" };
  return <span className={"text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg " + cfg[status]}>{status}</span>;
}

export default function ClientsPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const filtered = useMemo(() => clients.filter(c => {
    const matchSearch = !search || c.name.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "All" || c.status === statusFilter;
    return matchSearch && matchStatus;
  }), [search, statusFilter]);

  const activeCount = clients.filter(c => c.status === "Active").length;
  const lapsedCount = clients.filter(c => c.status === "Lapsed").length;
  const totalLTV = clients.reduce((s,c) => s+c.revenue, 0);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Client Registry</h1>
        <p className="text-sm text-[#6B7280] mt-1">{clients.length} unique clients · {activeCount} active this month</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Total Clients",   val:clients.length,  sub:"all time",              color:"#7C5CFC", bg:"#7C5CFC", Icon:Users       },
          { label:"Active (30 days)",val:activeCount,     sub:"ordered recently",       color:"#00E676", bg:"#00E676", Icon:TrendingUp  },
          { label:"Lapsed (90+ days)",val:lapsedCount,   sub:"need re-engagement",     color:"#F87171", bg:"#F87171", Icon:Clock       },
          { label:"Avg Client LTV",  val:"R "+(Math.round(totalLTV/clients.length)).toLocaleString("en-ZA"), sub:"lifetime value", color:"#C97010", bg:"#C97010", Icon:Award },
        ].map(k => (
          <div key={k.label} className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background:k.bg+"18" }}>
                <k.Icon size={16} style={{ color:k.color }} />
              </div>
              <span className="text-sm text-[#9BA3B7]">{k.label}</span>
            </div>
            <p className="text-2xl font-bold tracking-tight" style={{ color:k.color }}>{k.val}</p>
            <p className="text-xs text-[#4B5563] mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Top Clients by Revenue</h2>
          <p className="text-xs text-[#6B7280] mb-5">All time</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={topClientBars} barSize={36} margin={{ left:-20, right:4, top:4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="name" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={v => ["R "+v.toLocaleString("en-ZA"), "Revenue"]} labelStyle={{ color:"#9BA3B7" }} />
              <Bar dataKey="revenue" radius={[8,8,0,0]}>
                {topClientBars.map((_,i) => <Cell key={i} fill={barColors[i % barColors.length]} fillOpacity={0.85} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">New vs Repeat Revenue</h2>
          <p className="text-xs text-[#6B7280] mb-5">Last 4 months</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={newVsRepeat} barSize={20} barGap={3} margin={{ left:-20, right:4, top:4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="month" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={v => "R "+v.toLocaleString("en-ZA")} labelStyle={{ color:"#9BA3B7" }} />
              <Bar dataKey="newRev"    name="New client"    fill="#C97010" fillOpacity={0.8} radius={[4,4,0,0]} />
              <Bar dataKey="repeatRev" name="Repeat client" fill="#7C5CFC" fillOpacity={0.8} radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-3 text-xs text-[#6B7280]">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-[#C97010] inline-block" />New</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-[#7C5CFC] inline-block" />Repeat</span>
          </div>
        </div>
      </div>

      {/* Client Table */}
      <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4B5563]" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search clients..."
              className="w-full bg-[#13131A] border border-[#2A2A3E] rounded-xl pl-9 pr-4 py-2.5 text-sm text-[#D1D5DB] placeholder-[#4B5563] outline-none focus:border-[#7C5CFC]/50 transition-colors" />
          </div>
          <div className="flex items-center bg-[#13131A] border border-[#2A2A3E] rounded-xl p-1 gap-0.5">
            {["All","Active","Recent","Lapsed"].map(f => (
              <button key={f} onClick={() => setStatusFilter(f)}
                className={"text-xs font-medium px-3 py-1.5 rounded-lg transition-all " +
                  (statusFilter===f ? "bg-[#2A2A3E] text-white" : "text-[#6B7280] hover:text-[#D1D5DB]")}>
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1F2233]">
                {["#","Client","Jobs","Total Revenue","Avg Invoice","Outstanding","Last Job","Type","Status",""].map(h => (
                  <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-widest text-[#4B5563] pb-3 px-3 font-mono">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((c,i) => (
                <tr key={c.name} className="border-b border-[#1A1A28] last:border-0 hover:bg-[#13131A] transition-colors">
                  <td className="py-4 px-3 text-xs font-mono text-[#4B5563]">{i+1}</td>
                  <td className="py-4 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold" style={{ background: barColors[i%barColors.length]+"20", color: barColors[i%barColors.length] }}>
                        {c.name.slice(0,2).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">{c.name}</p>
                        {c.isNew && <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#C97010]/15 text-[#C97010]">New</span>}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-3 text-sm font-mono text-[#9BA3B7] text-center">{c.jobs}</td>
                  <td className="py-4 px-3 text-sm font-semibold text-[#C97010] font-mono">R {c.revenue.toLocaleString("en-ZA")}</td>
                  <td className="py-4 px-3 text-sm font-mono text-[#9BA3B7]">R {c.avgInvoice.toLocaleString("en-ZA")}</td>
                  <td className="py-4 px-3 text-sm font-mono" style={{ color: c.outstanding>0?"#F87171":"#00E676" }}>
                    {c.outstanding>0?"R "+c.outstanding.toLocaleString("en-ZA"):"—"}
                  </td>
                  <td className="py-4 px-3 text-xs text-[#6B7280] font-mono">{c.last}</td>
                  <td className="py-4 px-3">
                    <span className={"text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-lg " +
                      (c.isRepeat ? "bg-[#7C5CFC]/10 text-[#A78BFA]" : "bg-[#2DD4BF]/10 text-[#2DD4BF]")}>
                      {c.isRepeat ? "Repeat" : "Once-off"}
                    </span>
                  </td>
                  <td className="py-4 px-3"><StatusBadge status={c.status} /></td>
                  <td className="py-4 px-3">
                    <div className="flex gap-1.5">
                      <button className="p-1.5 bg-[#00E676]/10 hover:bg-[#00E676]/20 rounded-lg transition-colors"><Phone size={12} className="text-[#00E676]" /></button>
                      <button className="p-1.5 bg-[#7C5CFC]/10 hover:bg-[#7C5CFC]/20 rounded-lg transition-colors"><Mail size={12} className="text-[#A78BFA]" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
