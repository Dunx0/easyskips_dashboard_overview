"use client";
import { useState } from "react";
import { Settings, Palette, Bell, Database, Shield, User, ChevronRight, Check } from "lucide-react";

const THEMES = [
  { id:"midnight",    label:"Midnight (Default)", bg:"#13131A", accent:"#C97010", secondary:"#7C5CFC" },
  { id:"black-green", label:"Black & Green",      bg:"#080D0A", accent:"#1AB870", secondary:"#2DD4BF" },
  { id:"snow-orange", label:"Snow & Orange",      bg:"#EDEAE4", accent:"#C2660A", secondary:"#7C5CFC" },
  { id:"snow-green",  label:"Snow & Green",       bg:"#E6EDE8", accent:"#0B7A40", secondary:"#0D9488" },
];

function Section({ title, icon: Icon, children }) {
  return (
    <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-5 pb-4 border-b border-[#1F2233]">
        <div className="w-8 h-8 bg-[#7C5CFC]/15 rounded-xl flex items-center justify-center">
          <Icon size={15} className="text-[#A78BFA]" />
        </div>
        <h2 className="text-base font-semibold text-white">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function Row({ label, sub, children }) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-[#1A1A28] last:border-0">
      <div>
        <p className="text-sm font-medium text-[#D1D5DB]">{label}</p>
        {sub && <p className="text-xs text-[#4B5563] mt-0.5">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)}
      className={"w-11 h-6 rounded-full transition-colors duration-200 relative " + (on ? "bg-[#C97010]" : "bg-[#2A2A3E]")}>
      <span className={"absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 " + (on ? "translate-x-5" : "translate-x-0.5")} />
    </button>
  );
}

export default function SettingsPage() {
  const [theme, setTheme] = useState("midnight");
  const [notifs, setNotifs] = useState({ overdueAlerts:true, dailySummary:true, newInvoice:false, weeklyReport:true });
  const [sheetsUrl, setSheetsUrl] = useState("https://script.google.com/macros/s/AKfycbwDxPTb...");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    if (theme !== "midnight") document.documentElement.setAttribute("data-theme", theme);
    else document.documentElement.removeAttribute("data-theme");
    localStorage.setItem("es-theme", theme);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[900px] mx-auto fade-up">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Settings</h1>
        <p className="text-sm text-[#6B7280] mt-1">Configure your EasySkips portal</p>
      </div>

      {/* Profile */}
      <Section title="Profile" icon={User}>
        <Row label="Business Name" sub="Displayed in the portal header">
          <input defaultValue="Easy Skips Rustenburg"
            className="bg-[#13131A] border border-[#2A2A3E] rounded-xl px-4 py-2 text-sm text-[#D1D5DB] outline-none focus:border-[#7C5CFC]/50 w-64 transition-colors" />
        </Row>
        <Row label="Owner Name" sub="Shown on reports and invoices">
          <input defaultValue="Owner"
            className="bg-[#13131A] border border-[#2A2A3E] rounded-xl px-4 py-2 text-sm text-[#D1D5DB] outline-none focus:border-[#7C5CFC]/50 w-64 transition-colors" />
        </Row>
        <Row label="Location" sub="Used for distance estimates">
          <input defaultValue="Rustenburg, North West"
            className="bg-[#13131A] border border-[#2A2A3E] rounded-xl px-4 py-2 text-sm text-[#D1D5DB] outline-none focus:border-[#7C5CFC]/50 w-64 transition-colors" />
        </Row>
      </Section>

      {/* Theme */}
      <Section title="Appearance" icon={Palette}>
        <p className="text-sm text-[#6B7280] mb-4">Choose a colour theme for your dashboard</p>
        <div className="grid grid-cols-2 gap-3">
          {THEMES.map(t => (
            <button key={t.id} onClick={() => setTheme(t.id)}
              className={"flex items-center gap-3 p-4 rounded-xl border-2 transition-all " +
                (theme===t.id ? "border-[#7C5CFC] bg-[#7C5CFC]/5" : "border-[#2A2A3E] hover:border-[#3A3A5E]")}>
              <div className="w-10 h-10 rounded-xl flex-shrink-0 relative overflow-hidden border border-[#2A2A3E]" style={{ background:t.bg }}>
                <div className="absolute bottom-0 left-0 right-0 h-1/2" style={{ background:t.accent, opacity:0.8 }} />
                <div className="absolute top-1 right-1 w-3 h-3 rounded-full" style={{ background:t.secondary }} />
              </div>
              <span className="text-sm font-medium text-[#D1D5DB] text-left flex-1">{t.label}</span>
              {theme===t.id && <Check size={16} className="text-[#7C5CFC] flex-shrink-0" />}
            </button>
          ))}
        </div>
      </Section>

      {/* Notifications */}
      <Section title="Notifications" icon={Bell}>
        {[
          { key:"overdueAlerts",  label:"Overdue Invoice Alerts",  sub:"Notify when invoices pass 60 days"    },
          { key:"dailySummary",   label:"Daily Summary",           sub:"Morning briefing at 7:00 AM"          },
          { key:"newInvoice",     label:"New Invoice Created",     sub:"Ping when admin creates an invoice"   },
          { key:"weeklyReport",   label:"Weekly Report",           sub:"Monday morning performance summary"   },
        ].map(n => (
          <Row key={n.key} label={n.label} sub={n.sub}>
            <Toggle on={notifs[n.key]} onChange={v => setNotifs(prev => ({ ...prev, [n.key]:v }))} />
          </Row>
        ))}
      </Section>

      {/* Data connection */}
      <Section title="Data Connection" icon={Database}>
        <Row label="Google Sheets API URL" sub="Your Apps Script deployment URL">
          <div className="flex gap-2">
            <input value={sheetsUrl} onChange={e => setSheetsUrl(e.target.value)}
              className="bg-[#13131A] border border-[#2A2A3E] rounded-xl px-4 py-2 text-sm text-[#D1D5DB] outline-none focus:border-[#7C5CFC]/50 w-80 transition-colors font-mono text-xs" />
            <button className="bg-[#00E676]/10 border border-[#00E676]/20 text-[#00E676] text-xs font-semibold px-4 py-2 rounded-xl hover:bg-[#00E676]/20 transition-colors">
              Test
            </button>
          </div>
        </Row>
        <Row label="Sync Interval" sub="How often the dashboard refreshes">
          <select className="bg-[#13131A] border border-[#2A2A3E] rounded-xl px-4 py-2 text-sm text-[#D1D5DB] outline-none focus:border-[#7C5CFC]/50 transition-colors">
            <option>Every 2 minutes</option>
            <option>Every 5 minutes</option>
            <option>Every 10 minutes</option>
          </select>
        </Row>
      </Section>

      {/* Save */}
      <div className="flex justify-end">
        <button onClick={handleSave}
          className={"flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold transition-all " +
            (saved ? "bg-[#00E676] text-black" : "bg-gradient-to-r from-[#C97010] to-[#E88B1A] text-white shadow-lg shadow-[#C97010]/25 hover:opacity-90")}>
          {saved ? <><Check size={16} /> Saved!</> : "Save Changes"}
        </button>
      </div>
    </div>
  );
}
