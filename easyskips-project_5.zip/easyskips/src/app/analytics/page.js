"use client";
import { useState } from "react";
import { TrendingUp, BarChart3, Users, Zap } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis, PieChart, Pie } from "recharts";

const seasonal = [
  { month:"Jan", index:88,  revenue:38200 },
  { month:"Feb", index:82,  revenue:35600 },
  { month:"Mar", index:95,  revenue:41300 },
  { month:"Apr", index:102, revenue:44400 },
  { month:"May", index:112, revenue:48700 },
  { month:"Jun", index:78,  revenue:33900 },
  { month:"Jul", index:72,  revenue:31300 },
  { month:"Aug", index:80,  revenue:34800 },
  { month:"Sep", index:98,  revenue:42600 },
  { month:"Oct", index:108, revenue:46900 },
  { month:"Nov", index:118, revenue:51300 },
  { month:"Dec", index:105, revenue:45600 },
];

const peakDays = [
  { day:"Mon", jobs:8,  rev:14200 },
  { day:"Tue", jobs:12, rev:18400 },
  { day:"Wed", jobs:15, rev:22100 },
  { day:"Thu", jobs:14, rev:20800 },
  { day:"Fri", jobs:16, rev:24600 },
  { day:"Sat", jobs:9,  rev:13200 },
  { day:"Sun", jobs:3,  rev:4800  },
];

const skipLifecycle = [
  { state:"Depot",         pct:38.2, color:"#7C5CFC" },
  { state:"Outbound",      pct:8.4,  color:"#C97010"  },
  { state:"On-Site",       pct:44.1, color:"#00E676"  },
  { state:"Return",        pct:6.8,  color:"#2DD4BF"  },
  { state:"Out of Service",pct:2.5,  color:"#F87171"  },
];

const customerStates = [
  { state:"Active",   count:14, color:"#00E676" },
  { state:"Loyal",    count:8,  color:"#7C5CFC" },
  { state:"New",      count:5,  color:"#2DD4BF" },
  { state:"Lapsed",   count:11, color:"#F97316" },
  { state:"Inactive", count:19, color:"#F87171" },
];

const projectionData = [
  { month:"Jun", low:31000, mid:35000, high:40000 },
  { month:"Jul", low:29000, mid:33000, high:38000 },
  { month:"Aug", low:32000, mid:36000, high:41000 },
  { month:"Sep", low:40000, mid:44000, high:50000 },
  { month:"Oct", low:44000, mid:49000, high:55000 },
  { month:"Nov", low:48000, mid:54000, high:61000 },
];

export default function AnalyticsPage() {
  const peakMonth = [...seasonal].sort((a,b)=>b.index-a.index)[0];
  const peakDay = [...peakDays].sort((a,b)=>b.jobs-a.jobs)[0];
  const totalClients = customerStates.reduce((s,c)=>s+c.count,0);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Advanced Analytics</h1>
        <p className="text-sm text-[#6B7280] mt-1">Patterns, projections and lifecycle models</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Peak Month",       val:peakMonth.month,      sub:"index "+peakMonth.index, color:"#C97010", bg:"#C97010", Icon:TrendingUp },
          { label:"Busiest Day",      val:peakDay.day,          sub:peakDay.jobs+" avg jobs", color:"#00E676", bg:"#00E676", Icon:BarChart3  },
          { label:"Active Clients",   val:customerStates[0].count+customerStates[1].count, sub:"loyal + active", color:"#7C5CFC", bg:"#7C5CFC", Icon:Users },
          { label:"On-Site Right Now",val:"44%",                sub:"of total fleet",         color:"#2DD4BF", bg:"#2DD4BF", Icon:Zap        },
        ].map(k => (
          <div key={k.label} className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background:k.bg+"18" }}>
                <k.Icon size={16} style={{ color:k.color }} />
              </div>
              <span className="text-sm text-[#9BA3B7]">{k.label}</span>
            </div>
            <p className="text-2xl font-bold tracking-tight" style={{ color:k.color }}>{k.val}</p>
            <p className="text-xs text-[#4B5563] mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      {/* Seasonal + Peak Day */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Seasonal Demand Index</h2>
          <p className="text-xs text-[#6B7280] mb-1">Index 100 = average month · above 100 = busier than average</p>
          <div className="flex items-center gap-3 mb-5">
            <span className="text-xs text-[#4B5563]">Quieter</span>
            {[0.15,0.3,0.5,0.7,0.9].map((o,i) => (
              <div key={i} className="w-8 h-2 rounded" style={{ background:`rgba(201,112,16,${o})` }} />
            ))}
            <span className="text-xs text-[#4B5563]">Busier</span>
          </div>
          <div className="grid grid-cols-12 gap-1.5 mb-4">
            {seasonal.map(m => {
              const intensity = (m.index - 70) / (120 - 70);
              const isMax = m.month === peakMonth.month;
              return (
                <div key={m.month} className="flex flex-col items-center gap-1.5 group cursor-pointer">
                  <div className="w-full aspect-square rounded-xl flex items-center justify-center transition-transform group-hover:scale-110"
                    style={{ background:`rgba(201,112,16,${0.1 + intensity * 0.85})`, border: isMax ? "1px solid #C97010" : "1px solid transparent" }}>
                    <span className="text-[10px] font-mono font-bold" style={{ color: intensity>0.5?"#fff":"#C97010" }}>{m.index}</span>
                  </div>
                  <span className="text-[10px] font-mono" style={{ color: isMax ? "#C97010" : "#4B5563" }}>{m.month}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Peak Day of Week</h2>
          <p className="text-xs text-[#6B7280] mb-5">Average jobs per day</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={peakDays} barSize={28} margin={{ left:-20, right:4, top:4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="day" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:10, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={(v,n) => [v, n==="jobs" ? "Avg jobs" : "Revenue"]} labelStyle={{ color:"#9BA3B7" }} />
              <Bar dataKey="jobs" radius={[6,6,0,0]}>
                {peakDays.map((d,i) => <Cell key={i} fill={d.day===peakDay.day ? "#C97010" : "#7C5CFC"} fillOpacity={d.day===peakDay.day ? 1 : 0.5} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Revenue projection + lifecycle charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">6-Month Revenue Projection</h2>
          <p className="text-xs text-[#6B7280] mb-5">Based on seasonal index · low / mid / high scenarios</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={projectionData} margin={{ left:-20, right:4, top:4 }}>
              <defs>
                <linearGradient id="gHigh" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00E676" stopOpacity={0.2} /><stop offset="100%" stopColor="#00E676" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gMid" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#C97010" stopOpacity={0.2} /><stop offset="100%" stopColor="#C97010" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="month" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={v => "R "+v.toLocaleString("en-ZA")} labelStyle={{ color:"#9BA3B7" }} />
              <Area type="monotone" dataKey="high" name="High" stroke="#00E676" strokeWidth={1.5} strokeDasharray="4 3" fill="url(#gHigh)" dot={false} />
              <Area type="monotone" dataKey="mid"  name="Mid"  stroke="#C97010" strokeWidth={2.5} fill="url(#gMid)"  dot={false} activeDot={{ r:5, fill:"#C97010" }} />
              <Area type="monotone" dataKey="low"  name="Low"  stroke="#F87171" strokeWidth={1.5} strokeDasharray="4 3" fill="none" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex gap-5 mt-3 text-xs text-[#6B7280]">
            <span className="flex items-center gap-1.5"><span className="w-4 h-[2px] bg-[#00E676] inline-block rounded" />High</span>
            <span className="flex items-center gap-1.5"><span className="w-4 h-[2px] bg-[#C97010] inline-block rounded" />Mid</span>
            <span className="flex items-center gap-1.5"><span className="w-4 h-[2px] bg-[#F87171] inline-block rounded" />Low</span>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          {/* Skip lifecycle */}
          <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-white mb-1">Skip Lifecycle</h2>
            <p className="text-[11px] text-[#6B7280] mb-4">Markov steady state</p>
            <div className="space-y-2.5">
              {skipLifecycle.map(s => (
                <div key={s.state} className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background:s.color }} />
                  <span className="text-xs text-[#9BA3B7] flex-1">{s.state}</span>
                  <div className="w-24 h-1.5 bg-[#1F2233] rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width:s.pct+"%", background:s.color }} />
                  </div>
                  <span className="text-xs font-mono text-[#6B7280] w-10 text-right">{s.pct}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Customer lifecycle */}
          <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-white mb-1">Client Lifecycle</h2>
            <p className="text-[11px] text-[#6B7280] mb-4">RFM classification</p>
            <div className="space-y-2.5">
              {customerStates.map(c => (
                <div key={c.state} className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background:c.color }} />
                  <span className="text-xs text-[#9BA3B7] flex-1">{c.state}</span>
                  <div className="w-24 h-1.5 bg-[#1F2233] rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width:(c.count/totalClients*100)+"%", background:c.color }} />
                  </div>
                  <span className="text-xs font-mono text-[#6B7280] w-6 text-right">{c.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
