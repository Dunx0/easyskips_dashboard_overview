"use client";
import { useState } from "react";
import { Truck, MapPin, TrendingUp, Wrench, CheckCircle2, Clock } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, AreaChart, Area } from "recharts";

const vehicles = [
  { id: "Trok 1",   driver: "Joe",     type: "Fuso 6×4",        status: "Deployed",    jobs: 14, rev: 28400, util: 78, lastJob: "Buco Cash · Rustenburg North"  },
  { id: "Trok 2",   driver: "Tsepho",  type: "Hino 500",        status: "Deployed",    jobs: 11, rev: 22600, util: 65, lastJob: "Euro Sales · Waterval Boven"    },
  { id: "Trok 3",   driver: "Kagiso",  type: "MAN TGS",         status: "Available",   jobs: 13, rev: 26100, util: 71, lastJob: "Willie EFT · Rustenburg CBD"    },
  { id: "Trok 4",   driver: "James",   type: "Fuso FJ",         status: "Maintenance", jobs: 9,  rev: 18200, util: 58, lastJob: "Eloftus Lodge · Sun City Rd"   },
  { id: "Bakkie 1", driver: "Oom WP",  type: "Mahindra Pik Up", status: "Deployed",    jobs: 12, rev: 14100, util: 82, lastJob: "Lesego Builds · Geelhout Pk"   },
  { id: "Bakkie 2", driver: "Bennie",  type: "Mahindra Pik Up", status: "Available",   jobs: 8,  rev: 9800,  util: 55, lastJob: "Brigadoon · Industrial Area"    },
];

const skipInventory = [
  { size: "2m³", total: 8,  deployed: 5, color: "#60A5FA" },
  { size: "3m³", total: 6,  deployed: 3, color: "#A78BFA" },
  { size: "6m³", total: 20, deployed: 16, color: "#C97010" },
  { size: "9m³", total: 4,  deployed: 2, color: "#00E676" },
];

const weeklyRevenue = [
  { week: "Wk 1", trok1: 6200, trok2: 5100, trok3: 5800, bakkie1: 3200, bakkie2: 2100 },
  { week: "Wk 2", trok1: 7100, trok2: 5800, trok3: 6200, bakkie1: 3600, bakkie2: 2400 },
  { week: "Wk 3", trok1: 7600, trok2: 5900, trok3: 6800, bakkie1: 3800, bakkie2: 2600 },
  { week: "Wk 4", trok1: 7500, trok2: 5800, trok3: 7300, bakkie1: 3500, bakkie2: 2700 },
];

const barColors = ["#C97010","#7C5CFC","#00E676","#F87171","#2DD4BF","#F472B6"];

function StatusPill({ s }) {
  const cfg = { Deployed:"bg-[#00E676]/10 text-[#00E676]", Available:"bg-[#7C5CFC]/10 text-[#A78BFA]", Maintenance:"bg-[#F87171]/10 text-[#F87171]" };
  return <span className={"text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg " + cfg[s]}>{s}</span>;
}

export default function FleetPage() {
  const [filter, setFilter] = useState("All");
  const totalRev = vehicles.reduce((s,v) => s + v.rev, 0);
  const deployed = vehicles.filter(v => v.status === "Deployed").length;
  const totalSkips = skipInventory.reduce((s,f) => s + f.total, 0);
  const deployedSkips = skipInventory.reduce((s,f) => s + f.deployed, 0);
  const filtered = filter === "All" ? vehicles : vehicles.filter(v => v.status === filter);
  const revData = vehicles.map(v => ({ name: v.id, rev: v.rev, jobs: v.jobs }));

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Fleet Management</h1>
          <p className="text-sm text-[#6B7280] mt-1">6 vehicles · 38 skip containers · live status</p>
        </div>
        <div className="flex items-center bg-[#1C1C26] border border-[#2A2A3E] rounded-xl p-1 gap-0.5">
          {["All","Deployed","Available","Maintenance"].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={"text-xs font-medium px-3.5 py-2 rounded-lg transition-all " +
                (filter===f ? "bg-[#2A2A3E] text-white shadow" : "text-[#6B7280] hover:text-[#D1D5DB]")}>
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Vehicles Deployed",  val: deployed+" / 6",    color:"#00E676", bg:"#00E676", Icon:Truck        },
          { label:"Skips On-Site",      val: deployedSkips+" / "+totalSkips, color:"#C97010", bg:"#C97010", Icon:MapPin  },
          { label:"Fleet Revenue MTD",  val: "R "+(totalRev/1000).toFixed(1)+"k", color:"#7C5CFC", bg:"#7C5CFC", Icon:TrendingUp },
          { label:"In Maintenance",     val: "1 vehicle",         color:"#F87171", bg:"#F87171", Icon:Wrench       },
        ].map(k => (
          <div key={k.label} className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 hover:border-[#3A3A5E] transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: k.bg+"18" }}>
                <k.Icon size={16} style={{ color: k.color }} />
              </div>
              <span className="text-sm text-[#9BA3B7]">{k.label}</span>
            </div>
            <p className="text-2xl font-bold tracking-tight" style={{ color: k.color }}>{k.val}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Revenue per Vehicle</h2>
          <p className="text-xs text-[#6B7280] mb-5">This month</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={revData} barSize={36} margin={{ left:-20, right:4, top:4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="name" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={v => ["R "+v.toLocaleString("en-ZA"), "Revenue"]} labelStyle={{ color:"#9BA3B7", fontSize:12 }} />
              <Bar dataKey="rev" radius={[8,8,0,0]}>
                {revData.map((_,i) => <Cell key={i} fill={barColors[i % barColors.length]} fillOpacity={0.85} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Skip Inventory</h2>
          <p className="text-xs text-[#6B7280] mb-5">Deployed vs total</p>
          <div className="space-y-5">
            {skipInventory.map(s => (
              <div key={s.size}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-white">{s.size} Skips</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-[#9BA3B7]">{s.deployed} / {s.total}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md" style={{ background:s.color+"18", color:s.color }}>
                      {Math.round(s.deployed/s.total*100)}%
                    </span>
                  </div>
                </div>
                <div className="h-2.5 bg-[#1F2233] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700" style={{ width:(s.deployed/s.total*100)+"%", background:s.color }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-[#1F2233] flex justify-between">
            <span className="text-xs text-[#6B7280]">Overall Utilisation</span>
            <span className="text-sm font-bold text-[#00E676]">{Math.round(deployedSkips/totalSkips*100)}%</span>
          </div>
        </div>
      </div>

      {/* Vehicle table */}
      <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
        <h2 className="text-base font-semibold text-white mb-5">Vehicle Details</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1F2233]">
                {["Vehicle","Driver","Type","Status","Jobs MTD","Revenue MTD","Utilisation","Last Job"].map(h => (
                  <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-widest text-[#4B5563] pb-3 px-3 font-mono">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(v => (
                <tr key={v.id} className="border-b border-[#1A1A28] last:border-0 hover:bg-[#13131A] transition-colors">
                  <td className="py-4 px-3 text-sm font-bold text-white">{v.id}</td>
                  <td className="py-4 px-3 text-sm text-[#D1D5DB]">{v.driver}</td>
                  <td className="py-4 px-3 text-xs font-mono text-[#6B7280]">{v.type}</td>
                  <td className="py-4 px-3"><StatusPill s={v.status} /></td>
                  <td className="py-4 px-3 text-sm font-mono text-[#9BA3B7] text-center">{v.jobs}</td>
                  <td className="py-4 px-3 text-sm font-semibold text-[#C97010] font-mono">R {v.rev.toLocaleString("en-ZA")}</td>
                  <td className="py-4 px-3 w-40">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-[#1F2233] rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width:v.util+"%", background: v.util>70?"#00E676":v.util>50?"#FBBF24":"#F87171" }} />
                      </div>
                      <span className="text-xs font-mono text-[#9BA3B7]">{v.util}%</span>
                    </div>
                  </td>
                  <td className="py-4 px-3 text-xs text-[#6B7280] max-w-[200px] truncate">{v.lastJob}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
