"use client";
import { useState } from "react";
import { AlertTriangle, AlertCircle, Clock, CheckCircle2, Phone, Mail, TrendingDown } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from "recharts";

const ALL_INVOICES = [
  { id:"INV-0290", client:"Euro Sales",     date:"2026-05-26", payment:"Account", amount:1600,  banked:0,   vehicle:"Trok 2"   },
  { id:"INV-0287", client:"Eloftus Lodge",  date:"2026-04-28", payment:"Account", amount:1200,  banked:0,   vehicle:"Trok 4"   },
  { id:"INV-0280", client:"Brigadoon",      date:"2025-12-10", payment:"Account", amount:1200,  banked:900, vehicle:"Trok 3"   },
  { id:"INV-0277", client:"Eloftus Lodge",  date:"2026-04-01", payment:"Account", amount:900,   banked:0,   vehicle:"Trok 4"   },
  { id:"INV-0276", client:"Brigadoon",      date:"2026-02-14", payment:"Account", amount:750,   banked:0,   vehicle:"Bakkie 2" },
];

function daysSince(d) { return Math.floor((Date.now() - new Date(d)) / 86400000); }

const debtors = ALL_INVOICES.map(inv => ({
  ...inv,
  owing: inv.amount - inv.banked,
  days: daysSince(inv.date),
  age: (() => { const d = daysSince(inv.date); return d <= 30 ? "0–30" : d <= 60 ? "31–60" : "60+"; })(),
}));

const agingBars = [
  { bucket:"0–30 days",  amount: debtors.filter(d=>d.age==="0–30").reduce((s,d)=>s+d.owing,0), count: debtors.filter(d=>d.age==="0–30").length, color:"#FBBF24" },
  { bucket:"31–60 days", amount: debtors.filter(d=>d.age==="31–60").reduce((s,d)=>s+d.owing,0), count: debtors.filter(d=>d.age==="31–60").length, color:"#F97316" },
  { bucket:"60+ days",   amount: debtors.filter(d=>d.age==="60+").reduce((s,d)=>s+d.owing,0), count: debtors.filter(d=>d.age==="60+").length, color:"#F87171" },
];

const collHistory = [
  { month:"Oct", invoiced:4200, collected:4200 },
  { month:"Nov", invoiced:3800, collected:3200 },
  { month:"Dec", invoiced:2400, collected:2400 },
  { month:"Jan", invoiced:5100, collected:4600 },
  { month:"Feb", invoiced:4800, collected:3900 },
  { month:"Mar", invoiced:6200, collected:5800 },
  { month:"Apr", invoiced:5600, collected:4200 },
  { month:"May", invoiced:7200, collected:5800 },
];

function AgeBadge({ age }) {
  const cfg = { "0–30":"bg-[#FBBF24]/10 text-[#FBBF24]", "31–60":"bg-[#F97316]/10 text-[#F97316]", "60+":"bg-[#F87171]/10 text-[#F87171]" };
  return <span className={"text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg " + cfg[age]}>{age} days</span>;
}

export default function DebtorsPage() {
  const totalOwing = debtors.reduce((s,d) => s+d.owing, 0);
  const critical = debtors.filter(d => d.age === "60+");

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Debtor Management</h1>
        <p className="text-sm text-[#6B7280] mt-1">{debtors.length} open invoices · R {totalOwing.toLocaleString("en-ZA")} outstanding</p>
      </div>

      {/* Critical alert */}
      {critical.length > 0 && (
        <div className="bg-[#F87171]/5 border border-[#F87171]/20 rounded-2xl p-5 flex items-center gap-4">
          <div className="w-10 h-10 bg-[#F87171]/15 rounded-xl flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={18} className="text-[#F87171]" />
          </div>
          <div>
            <p className="text-sm font-semibold text-[#F87171]">{critical.length} invoice{critical.length>1?"s":""} critically overdue (60+ days)</p>
            <p className="text-xs text-[#6B7280] mt-0.5">
              R {critical.reduce((s,d)=>s+d.owing,0).toLocaleString("en-ZA")} at serious collection risk — immediate action required
            </p>
          </div>
          <div className="ml-auto flex gap-2">
            <button className="flex items-center gap-2 bg-[#F87171]/10 border border-[#F87171]/20 text-[#F87171] text-xs font-semibold px-4 py-2 rounded-xl hover:bg-[#F87171]/20 transition-colors">
              <Phone size={13} /> Call Now
            </button>
            <button className="flex items-center gap-2 bg-[#1C1C26] border border-[#2A2A3E] text-[#9BA3B7] text-xs font-semibold px-4 py-2 rounded-xl hover:text-white transition-colors">
              <Mail size={13} /> Send Statement
            </button>
          </div>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Total Outstanding", val:"R "+totalOwing.toLocaleString("en-ZA"),                      color:"#F87171", bg:"#F87171", Icon:TrendingDown },
          { label:"0–30 Days",         val:"R "+agingBars[0].amount.toLocaleString("en-ZA"),            color:"#FBBF24", bg:"#FBBF24", Icon:Clock },
          { label:"31–60 Days",        val:"R "+agingBars[1].amount.toLocaleString("en-ZA"),            color:"#F97316", bg:"#F97316", Icon:AlertCircle },
          { label:"60+ Days (Critical)",val:"R "+agingBars[2].amount.toLocaleString("en-ZA"),           color:"#F87171", bg:"#F87171", Icon:AlertTriangle },
        ].map(k => (
          <div key={k.label} className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background:k.bg+"18" }}>
                <k.Icon size={16} style={{ color:k.color }} />
              </div>
              <span className="text-sm text-[#9BA3B7]">{k.label}</span>
            </div>
            <p className="text-2xl font-bold tracking-tight" style={{ color:k.color }}>{k.val}</p>
          </div>
        ))}
      </div>

      {/* Aging chart + collection history */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Aging Breakdown</h2>
          <p className="text-xs text-[#6B7280] mb-5">Outstanding amounts by age bucket</p>
          <div className="space-y-4">
            {agingBars.map(b => (
              <div key={b.bucket}>
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ background:b.color }} />
                    <span className="text-sm text-[#D1D5DB]">{b.bucket}</span>
                    <span className="text-xs font-mono text-[#4B5563]">{b.count} invoice{b.count!==1?"s":""}</span>
                  </div>
                  <span className="text-sm font-semibold font-mono" style={{ color:b.color }}>R {b.amount.toLocaleString("en-ZA")}</span>
                </div>
                <div className="h-3 bg-[#1F2233] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: totalOwing>0 ? (b.amount/totalOwing*100)+"%" : "0%", background:b.color }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-[#1F2233] grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-[#6B7280]">Total at risk</p>
              <p className="text-lg font-bold text-[#F87171] mt-1">R {totalOwing.toLocaleString("en-ZA")}</p>
            </div>
            <div>
              <p className="text-xs text-[#6B7280]">Collection rate (all-time)</p>
              <p className="text-lg font-bold text-[#00E676] mt-1">81.4%</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Collection History</h2>
          <p className="text-xs text-[#6B7280] mb-5">Invoiced vs collected · last 8 months</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={collHistory} barSize={20} barGap={3} margin={{ left:-20, right:4, top:4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="month" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                formatter={v => "R "+v.toLocaleString("en-ZA")} labelStyle={{ color:"#9BA3B7" }} />
              <Bar dataKey="invoiced"  name="Invoiced"  fill="#7C5CFC" fillOpacity={0.5} radius={[4,4,0,0]} />
              <Bar dataKey="collected" name="Collected" fill="#00E676" fillOpacity={0.8} radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Debtor table */}
      <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
        <h2 className="text-base font-semibold text-white mb-5">Open Invoices</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1F2233]">
                {["Invoice","Client","Date","Days","Amount","Owing","Age","Payment","Action"].map(h => (
                  <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-widest text-[#4B5563] pb-3 px-3 font-mono">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {debtors.sort((a,b) => b.days-a.days).map(d => (
                <tr key={d.id} className="border-b border-[#1A1A28] last:border-0 hover:bg-[#13131A] transition-colors">
                  <td className="py-4 px-3 text-[11px] font-mono text-[#6B7280]">{d.id}</td>
                  <td className="py-4 px-3 text-sm font-semibold text-white">{d.client}</td>
                  <td className="py-4 px-3 text-xs font-mono text-[#6B7280]">{d.date}</td>
                  <td className="py-4 px-3 text-sm font-mono" style={{ color: d.days>60?"#F87171":d.days>30?"#F97316":"#FBBF24" }}>{d.days}d</td>
                  <td className="py-4 px-3 text-sm font-mono text-[#9BA3B7]">R {d.amount.toLocaleString("en-ZA")}</td>
                  <td className="py-4 px-3 text-sm font-semibold text-[#F87171] font-mono">R {d.owing.toLocaleString("en-ZA")}</td>
                  <td className="py-4 px-3"><AgeBadge age={d.age} /></td>
                  <td className="py-4 px-3 text-xs text-[#6B7280]">{d.payment}</td>
                  <td className="py-4 px-3">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 bg-[#00E676]/10 hover:bg-[#00E676]/20 rounded-lg transition-colors" title="Call client">
                        <Phone size={12} className="text-[#00E676]" />
                      </button>
                      <button className="p-1.5 bg-[#7C5CFC]/10 hover:bg-[#7C5CFC]/20 rounded-lg transition-colors" title="Send statement">
                        <Mail size={12} className="text-[#A78BFA]" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
