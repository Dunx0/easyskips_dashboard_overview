'use client';

import { useState } from 'react';
import { invoices, skipFleet, seasonal, costs } from '@/lib/data';
import { R, Rk, pct, daysSince, monthKey, shortMonth, buildFirstSeen, buildClientMap, parseItems, filterByPeriod, getPreviousPeriod } from '@/lib/helpers';
import KPICard from '@/components/KPICard';
import FilterBar from '@/components/FilterBar';

export default function SummaryPage() {
  const [period, setPeriod] = useState('month');
  const now = new Date();
  const filtered = filterByPeriod(invoices, period);
  const prev = getPreviousPeriod(invoices, period);

  const rev = filtered.reduce((s, i) => s + i.amount, 0);
  const revP = prev.reduce((s, i) => s + i.amount, 0);
  const delta = revP > 0 ? ((rev - revP) / revP * 100) : 0;

  const bkd = filtered.reduce((s, i) => s + i.banked, 0);
  const bkdP = prev.reduce((s, i) => s + i.banked, 0);
  const bkdDelta = bkdP > 0 ? ((bkd - bkdP) / bkdP * 100) : 0;

  const outstanding = rev - bkd;
  const outP = revP - bkdP;
  const outDelta = outP > 0 ? ((outstanding - outP) / outP * 100) : 0;

  const totalCost = filtered.reduce((s, i) => s + (costs[i.hire] || 450), 0);
  const netIncome = rev - totalCost;
  const netP = prev.reduce((s, i) => s + i.amount - (costs[i.hire] || 450), 0);
  const netDelta = netP > 0 ? ((netIncome - netP) / netP * 100) : 0;

  // Monthly bar chart data (last 12 months)
  const barData = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = monthKey(d);
    const mi = invoices.filter(x => x.date.startsWith(mk));
    const r = mi.reduce((s, x) => s + x.amount, 0);
    const c = mi.reduce((s, x) => s + (costs[x.hire] || 450), 0);
    barData.push({ label: shortMonth(d), rev: r, cost: c, isCurrent: i === 0 });
  }
  const barMax = Math.max(...barData.map(b => Math.max(b.rev, b.cost)), 1);

  // Payment mix
  const payMix = {};
  filtered.forEach(i => { payMix[i.payment] = (payMix[i.payment] || 0) + i.amount; });
  const payTotal = Object.values(payMix).reduce((s, v) => s + v, 0) || 1;
  const payColors = { EFT: 'var(--accent)', Card: 'var(--green)', Cash: 'var(--amber)', Account: 'var(--purple)' };

  // Skip mix
  const skipRev = { s2: 0, s3: 0, s6: 0, s9: 0 };
  filtered.forEach(i => {
    const sk = parseItems(i.items);
    const t = Object.values(sk).reduce((s, v) => s + v, 0) || 1;
    Object.entries(sk).forEach(([k, v]) => { skipRev[k] += (v / t) * i.amount; });
  });
  const skipTotal = Object.values(skipRev).reduce((s, v) => s + v, 0) || 1;

  // Debrief
  const unpaid = invoices.filter(i => i.banked < i.amount);
  const a90 = unpaid.filter(i => daysSince(i.date) > 60);
  const firstSeen = buildFirstSeen(invoices);
  const busyMo = Object.entries(seasonal).sort((a, b) => b[1] - a[1])[0][0];

  return (
    <div>
      <FilterBar current={period} onChange={setPeriod} />

      {/* ═══ MAIN: BAR CHART + KPI SIDEBAR ═══ */}
      <div className="grid grid-cols-[1fr_320px] gap-5 mb-5">

        {/* Bar chart card */}
        <div className="es-card">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold mb-0.5">Revenue vs Cost</h3>
              <p className="text-xs text-[var(--ink3)]">Monthly comparison · last 12 months</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[var(--accent)]" /> Revenue
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[var(--secondary)]" /> Est. Cost
              </span>
            </div>
          </div>

          {/* Y-axis labels + bars */}
          <div className="flex gap-4">
            <div className="flex flex-col justify-between text-right font-mono text-[10px] text-[var(--ink3)] py-1" style={{ height: 200 }}>
              <span>{Rk(barMax)}</span>
              <span>{Rk(barMax * 0.5)}</span>
              <span>R0</span>
            </div>
            <div className="flex-1 flex items-end gap-[3px]" style={{ height: 200 }}>
              {barData.map((b, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-0.5 h-full justify-end">
                  <div className="w-full flex gap-[2px] items-end flex-1">
                    <div className="flex-1 rounded-t-[3px] transition-all duration-500"
                      style={{
                        height: `${Math.max((b.rev / barMax) * 100, b.rev ? 2 : 0)}%`,
                        background: b.isCurrent ? 'var(--accent)' : 'var(--accent-soft)',
                        opacity: b.isCurrent ? 1 : 0.35,
                      }} />
                    <div className="flex-1 rounded-t-[3px] transition-all duration-500"
                      style={{
                        height: `${Math.max((b.cost / barMax) * 100, b.cost ? 2 : 0)}%`,
                        background: 'var(--secondary)',
                        opacity: b.isCurrent ? 0.9 : 0.2,
                      }} />
                  </div>
                  <span className={`text-[10px] font-mono mt-1 ${b.isCurrent ? 'text-[var(--ink)] font-semibold' : 'text-[var(--ink3)]'}`}>
                    {b.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* KPI sidebar */}
        <div className="flex flex-col gap-4">
          <div className="es-card">
            <KPICard label="Total Revenue" value={R(rev)}
              change={`${delta >= 0 ? '+' : ''}${delta.toFixed(1)}%`}
              direction={delta >= 0 ? 'up' : 'down'} />
          </div>
          <div className="es-card">
            <KPICard label="Total Collected" value={R(bkd)}
              change={`${bkdDelta >= 0 ? '+' : ''}${bkdDelta.toFixed(1)}%`}
              direction={bkdDelta >= 0 ? 'up' : 'down'} />
          </div>
          <div className="es-card">
            <KPICard label="Est. Net Income" value={R(netIncome)}
              change={`${netDelta >= 0 ? '+' : ''}${netDelta.toFixed(1)}%`}
              direction={netDelta >= 0 ? 'up' : 'down'} />
          </div>
        </div>
      </div>

      {/* ═══ BOTTOM ROW: 3 CARDS ═══ */}
      <div className="grid grid-cols-3 gap-5 mb-5">

        {/* Payment Mix */}
        <div className="es-card">
          <h3 className="text-lg font-semibold mb-1">Payment Mix</h3>
          <p className="text-xs text-[var(--ink3)] mb-5">Revenue by payment type</p>
          <div className="text-[32px] font-semibold tracking-tight mb-4">{R(rev)}</div>

          {/* Stacked bar */}
          <div className="flex h-3 rounded-full overflow-hidden mb-5">
            {Object.entries(payMix).map(([type, amt]) => (
              <div key={type} style={{ width: `${(amt / payTotal) * 100}%`, background: payColors[type] || 'var(--accent)' }} />
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3">
            {Object.entries(payMix).sort((a, b) => b[1] - a[1]).map(([type, amt]) => (
              <div key={type}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: payColors[type] || 'var(--accent)' }} />
                  <span className="text-xs text-[var(--ink3)]">{type}</span>
                </div>
                <div className="font-semibold text-lg">{Rk(amt)}</div>
                <div className="text-xs text-[var(--ink3)] font-mono">{pct(amt / payTotal * 100)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Skip Size Mix — Donut */}
        <div className="es-card">
          <h3 className="text-lg font-semibold mb-1">Skip Size Mix</h3>
          <p className="text-xs text-[var(--ink3)] mb-5">Revenue contribution by container</p>

          <div className="flex items-center gap-6">
            {/* SVG donut */}
            <svg viewBox="0 0 100 100" className="w-[130px] h-[130px] flex-shrink-0">
              {(() => {
                const entries = Object.entries(skipRev).filter(([, v]) => v > 0);
                let offset = 0;
                return entries.map(([k, v]) => {
                  const pctVal = (v / skipTotal) * 100;
                  const dash = `${pctVal * 2.51327} ${251.327}`;
                  const el = (
                    <circle key={k} cx="50" cy="50" r="40"
                      fill="none" stroke={skipFleet[k].color} strokeWidth="12"
                      strokeDasharray={dash}
                      strokeDashoffset={-offset * 2.51327}
                      transform="rotate(-90 50 50)" style={{ opacity: 0.85 }} />
                  );
                  offset += pctVal;
                  return el;
                });
              })()}
              <text x="50" y="47" textAnchor="middle" fill="var(--ink)" fontSize="16" fontWeight="600">
                {filtered.reduce((s, i) => { const sk = parseItems(i.items); return s + Object.values(sk).reduce((a, v) => a + v, 0); }, 0)}
              </text>
              <text x="50" y="60" textAnchor="middle" fill="var(--ink3)" fontSize="8">Total</text>
            </svg>

            <div className="flex flex-col gap-3 flex-1">
              {Object.entries(skipRev).filter(([, v]) => v > 0).map(([k, v]) => (
                <div key={k} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ background: skipFleet[k].color }} />
                    <span className="text-sm">{skipFleet[k].label}</span>
                  </div>
                  <span className="font-mono text-sm text-[var(--ink3)]">{pct(v / skipTotal * 100)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Daily Debrief */}
        <div className="es-card flex flex-col">
          <h3 className="text-lg font-semibold mb-1">Daily Debrief</h3>
          <p className="text-xs text-[var(--ink3)] mb-4">AI-generated summary</p>

          <p className="text-sm text-[var(--ink2)] leading-relaxed flex-1">
            This period Easy Skips invoiced <strong className="text-[var(--ink)]">{R(rev)}</strong> and
            collected <strong className="text-[var(--ink)]">{R(bkd)}</strong>.
            {delta >= 0
              ? ` Revenue is up ${Math.abs(delta).toFixed(1)}% vs the prior period.`
              : ` Revenue is down ${Math.abs(delta).toFixed(1)}% — worth watching.`}
            {unpaid.length > 0
              ? ` ${unpaid.length} unpaid invoice${unpaid.length !== 1 ? 's' : ''} remain on the books.`
              : ' All invoices are settled.'}
            {a90.length > 0 ? ` ${a90.length} are over 60 days old — urgent.` : ''}
          </p>

          {a90.length > 0 && (
            <div className="mt-auto pt-3 border-t border-[var(--line)] bg-[var(--red-dim)] rounded-lg p-3 mt-3">
              <p className="text-xs">
                <strong className="text-[var(--red)]">Action required:</strong>
                <span className="text-[var(--ink3)]"> {a90.length} invoice{a90.length !== 1 ? 's' : ''} over 60 days. {R(a90.reduce((s, i) => s + (i.amount - i.banked), 0))} at risk.</span>
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ═══ INVOICE TABLE ═══ */}
      <div className="es-card">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-lg font-semibold">Recent Invoices</h3>
            <p className="text-xs text-[var(--ink3)]">Most recent first</p>
          </div>
          <span className="font-mono text-xs text-[var(--ink3)]">{filtered.length} jobs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--line)]">
                {['Invoice', 'Client', 'Date', 'Skips', 'Hire', 'Driver', 'Amount', 'Owing', 'Status'].map(h => (
                  <th key={h} className="text-[11px] font-mono text-[var(--ink3)] font-normal px-3 py-3 text-left">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...filtered].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 15).map(inv => {
                const owing = inv.amount - inv.banked;
                const sk = parseItems(inv.items);
                const skStr = Object.entries(sk).filter(([, v]) => v > 0).map(([k, v]) => `${v}×${skipFleet[k].label}`).join(', ');
                const isNew = buildFirstSeen(invoices)[inv.client] === inv.date;

                return (
                  <tr key={inv.id} className="border-b border-[var(--line)] last:border-0 hover:bg-[var(--bg2)] transition-colors">
                    <td className="px-3 py-3 font-mono text-xs text-[var(--ink3)]">{inv.id}</td>
                    <td className="px-3 py-3 text-sm">
                      {inv.client}
                      {isNew && <span className="ml-2 text-[9px] font-mono bg-[var(--accent-dim)] text-[var(--accent2)] px-1.5 py-0.5 rounded">NEW</span>}
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-[var(--ink3)]">{inv.date}</td>
                    <td className="px-3 py-3 font-mono text-xs">{skStr}</td>
                    <td className="px-3 py-3 text-xs">{inv.hire}</td>
                    <td className="px-3 py-3 text-xs text-[var(--ink3)]">{inv.driver}</td>
                    <td className="px-3 py-3 font-mono text-sm text-[var(--accent)]">{R(inv.amount)}</td>
                    <td className={`px-3 py-3 font-mono text-sm ${owing > 0 ? 'text-[var(--red)]' : 'text-[var(--green)]'}`}>
                      {owing > 0 ? R(owing) : 'Paid'}
                    </td>
                    <td className="px-3 py-3">
                      <span className={`text-[10px] font-mono px-2 py-1 rounded-full ${owing > 0 ? 'bg-[var(--red-dim)] text-[var(--red)]' : 'bg-[var(--green-dim)] text-[var(--green)]'}`}>
                        {owing > 0 ? 'Owing' : 'Settled'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
