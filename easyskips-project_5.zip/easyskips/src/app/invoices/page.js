"use client";
import { useState, useMemo } from "react";
import { Search, Filter, Download, FileText, CheckCircle2, AlertCircle, Clock, TrendingUp } from "lucide-react";
import { ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

const ALL_INVOICES = [
  { id:"INV-0291", client:"Buco Cash",      date:"2026-05-28", hire:"Weekly",  payment:"EFT",     amount:1350,  banked:1350,  vehicle:"Trok 1",   driver:"Joe",    items:"3× 6m³" },
  { id:"INV-0290", client:"Euro Sales",     date:"2026-05-26", hire:"Monthly", payment:"Account", amount:1600,  banked:0,     vehicle:"Trok 2",   driver:"Tsepho", items:"2× 6m³, 1× 2m³" },
  { id:"INV-0289", client:"Shelly Park",    date:"2026-05-22", hire:"Weekly",  payment:"Card",    amount:2700,  banked:2700,  vehicle:"Trok 1",   driver:"Joe",    items:"4× 6m³, 2× 2m³" },
  { id:"INV-0288", client:"Willie EFT",     date:"2026-05-18", hire:"Weekly",  payment:"EFT",     amount:2250,  banked:2250,  vehicle:"Trok 3",   driver:"Kagiso", items:"5× 6m³" },
  { id:"INV-0287", client:"Eloftus Lodge",  date:"2026-04-28", hire:"Monthly", payment:"Account", amount:1200,  banked:0,     vehicle:"Trok 4",   driver:"James",  items:"2× 6m³, 1× 9m³" },
  { id:"INV-0286", client:"Lesego Builds",  date:"2026-04-15", hire:"Daily",   payment:"Cash",    amount:850,   banked:850,   vehicle:"Bakkie 1", driver:"Oom WP", items:"1× 6m³, 2× 3m³" },
  { id:"INV-0285", client:"Jaco EFT",       date:"2026-04-10", hire:"Weekly",  payment:"EFT",     amount:1800,  banked:1800,  vehicle:"Trok 2",   driver:"Tsepho", items:"3× 6m³, 1× 2m³" },
  { id:"INV-0284", client:"Pink Rocks",     date:"2026-03-20", hire:"Monthly", payment:"Account", amount:2700,  banked:2700,  vehicle:"Trok 1",   driver:"Joe",    items:"6× 6m³" },
  { id:"INV-0283", client:"Air Products",   date:"2026-03-15", hire:"Weekly",  payment:"EFT",     amount:1800,  banked:1800,  vehicle:"Bakkie 2", driver:"Bennie", items:"2× 6m³, 2× 2m³" },
  { id:"INV-0282", client:"RHS Hoer Skool", date:"2026-02-20", hire:"Daily",   payment:"Cash",    amount:700,   banked:700,   vehicle:"Bakkie 1", driver:"Oom WP", items:"1× 6m³, 1× 3m³" },
  { id:"INV-0281", client:"Buco Cash",      date:"2026-01-15", hire:"Weekly",  payment:"EFT",     amount:1350,  banked:1350,  vehicle:"Trok 1",   driver:"Joe",    items:"3× 6m³" },
  { id:"INV-0280", client:"Brigadoon",      date:"2025-12-10", hire:"Monthly", payment:"Account", amount:1200,  banked:900,   vehicle:"Trok 3",   driver:"Kagiso", items:"2× 6m³, 1× 9m³" },
  { id:"INV-0279", client:"Crane Corp",     date:"2025-09-20", hire:"Monthly", payment:"Account", amount:4200,  banked:4200,  vehicle:"Trok 4",   driver:"James",  items:"8× 6m³, 2× 9m³" },
  { id:"INV-0278", client:"Concept Mining", date:"2025-07-10", hire:"Monthly", payment:"Account", amount:4500,  banked:4500,  vehicle:"Trok 2",   driver:"Tsepho", items:"10× 6m³" },
  { id:"INV-0277", client:"Eloftus Lodge",  date:"2026-04-01", hire:"Monthly", payment:"Account", amount:900,   banked:0,     vehicle:"Trok 4",   driver:"James",  items:"2× 6m³" },
  { id:"INV-0276", client:"Brigadoon",      date:"2026-02-14", hire:"Weekly",  payment:"Account", amount:750,   banked:0,     vehicle:"Bakkie 2", driver:"Bennie", items:"1× 6m³, 1× 2m³" },
];

const payColors = { EFT:"#00E676", Account:"#7C5CFC", Card:"#2DD4BF", Cash:"#FBBF24" };
const hireColors = { Weekly:"#C97010", Monthly:"#7C5CFC", Daily:"#2DD4BF", Weekend:"#F472B6" };

const monthlyTrend = [
  { m:"Sep", invoiced:9800,  collected:9800  },
  { m:"Oct", invoiced:12400, collected:11200 },
  { m:"Nov", invoiced:11000, collected:10400 },
  { m:"Dec", invoiced:8600,  collected:8200  },
  { m:"Jan", invoiced:13200, collected:12100 },
  { m:"Feb", invoiced:14800, collected:13400 },
  { m:"Mar", invoiced:16200, collected:14800 },
  { m:"Apr", invoiced:18100, collected:15600 },
  { m:"May", invoiced:20050, collected:16850 },
];

function getStatus(inv) {
  const days = Math.floor((Date.now() - new Date(inv.date)) / 86400000);
  if (inv.banked >= inv.amount) return "Settled";
  if (days > 60) return "Overdue";
  return "Owing";
}

function StatusBadge({ status }) {
  const cfg = { Settled:"bg-[#00E676]/10 text-[#00E676]", Owing:"bg-[#FBBF24]/10 text-[#FBBF24]", Overdue:"bg-[#F87171]/10 text-[#F87171]" };
  return <span className={"text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg " + cfg[status]}>{status}</span>;
}

export default function InvoicesPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [payFilter, setPayFilter] = useState("All");

  const invoices = useMemo(() => {
    return ALL_INVOICES.filter(inv => {
      const status = getStatus(inv);
      const matchSearch = !search || inv.client.toLowerCase().includes(search.toLowerCase()) || inv.id.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "All" || status === statusFilter;
      const matchPay = payFilter === "All" || inv.payment === payFilter;
      return matchSearch && matchStatus && matchPay;
    });
  }, [search, statusFilter, payFilter]);

  const totalInvoiced = ALL_INVOICES.reduce((s,i) => s+i.amount, 0);
  const totalCollected = ALL_INVOICES.reduce((s,i) => s+i.banked, 0);
  const totalOwing = totalInvoiced - totalCollected;
  const settled = ALL_INVOICES.filter(i => getStatus(i) === "Settled").length;

  // Payment mix data
  const payMix = Object.entries(
    ALL_INVOICES.reduce((m,i) => { m[i.payment] = (m[i.payment]||0) + i.amount; return m; }, {})
  ).map(([name,value]) => ({ name, value, color: payColors[name] }));

  const hireMix = Object.entries(
    ALL_INVOICES.reduce((m,i) => { m[i.hire] = (m[i.hire]||0) + i.amount; return m; }, {})
  ).map(([name,value]) => ({ name, value, color: hireColors[name] }));

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Invoices</h1>
        <p className="text-sm text-[#6B7280] mt-1">{ALL_INVOICES.length} total invoices · {settled} settled</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Total Invoiced",  val:"R "+totalInvoiced.toLocaleString("en-ZA"), color:"#C97010", bg:"#C97010", Icon:FileText   },
          { label:"Cash Collected",  val:"R "+totalCollected.toLocaleString("en-ZA"), color:"#00E676", bg:"#00E676", Icon:CheckCircle2 },
          { label:"Outstanding",     val:"R "+totalOwing.toLocaleString("en-ZA"),     color:"#F87171", bg:"#F87171", Icon:AlertCircle  },
          { label:"Collection Rate", val:Math.round(totalCollected/totalInvoiced*100)+"%", color:"#7C5CFC", bg:"#7C5CFC", Icon:TrendingUp },
        ].map(k => (
          <div key={k.label} className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 hover:border-[#3A3A5E] transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background:k.bg+"18" }}>
                <k.Icon size={16} style={{ color:k.color }} />
              </div>
              <span className="text-sm text-[#9BA3B7]">{k.label}</span>
            </div>
            <p className="text-2xl font-bold tracking-tight" style={{ color:k.color }}>{k.val}</p>
          </div>
        ))}
      </div>

      {/* Trend + mix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <h2 className="text-base font-semibold text-white mb-1">Invoice Trend</h2>
          <p className="text-xs text-[#6B7280] mb-5">Invoiced vs Collected · last 9 months</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={monthlyTrend} margin={{ left:-20, right:4, top:4 }}>
              <defs>
                <linearGradient id="gInv" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#C97010" stopOpacity={0.25} /><stop offset="100%" stopColor="#C97010" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gCol" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00E676" stopOpacity={0.2} /><stop offset="100%" stopColor="#00E676" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="m" tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:"#4B5563", fontSize:11, fontFamily:"JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => "R"+v/1000+"k"} />
              <Tooltip contentStyle={{ background:"#1C1C26", border:"1px solid #2A2A3E", borderRadius:12 }}
                labelStyle={{ color:"#9BA3B7" }} itemStyle={{ color:"#F0F2F8" }}
                formatter={v => "R "+v.toLocaleString("en-ZA")} />
              <Area type="monotone" dataKey="invoiced"  name="Invoiced"  stroke="#C97010" strokeWidth={2.5} fill="url(#gInv)" dot={false} activeDot={{ r:5, fill:"#C97010" }} />
              <Area type="monotone" dataKey="collected" name="Collected" stroke="#00E676" strokeWidth={2.5} fill="url(#gCol)" dot={false} activeDot={{ r:5, fill:"#00E676" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="flex flex-col gap-4">
          {/* Payment mix */}
          <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 flex-1">
            <h2 className="text-sm font-semibold text-white mb-4">Payment Methods</h2>
            <div className="space-y-3">
              {payMix.sort((a,b) => b.value-a.value).map(p => (
                <div key={p.name}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span style={{ color:p.color }} className="font-medium">{p.name}</span>
                    <span className="font-mono text-[#9BA3B7]">R {(p.value/1000).toFixed(1)}k</span>
                  </div>
                  <div className="h-1.5 bg-[#1F2233] rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width:(p.value/totalInvoiced*100)+"%", background:p.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* Hire type mix */}
          <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 flex-1">
            <h2 className="text-sm font-semibold text-white mb-4">Hire Types</h2>
            <div className="space-y-3">
              {hireMix.sort((a,b) => b.value-a.value).map(h => (
                <div key={h.name}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span style={{ color:h.color }} className="font-medium">{h.name}</span>
                    <span className="font-mono text-[#9BA3B7]">R {(h.value/1000).toFixed(1)}k</span>
                  </div>
                  <div className="h-1.5 bg-[#1F2233] rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width:(h.value/totalInvoiced*100)+"%", background:h.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Filters + Table */}
      <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4B5563]" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search invoices or clients..."
              className="w-full bg-[#13131A] border border-[#2A2A3E] rounded-xl pl-9 pr-4 py-2.5 text-sm text-[#D1D5DB] placeholder-[#4B5563] outline-none focus:border-[#7C5CFC]/50 transition-colors" />
          </div>
          <div className="flex items-center bg-[#13131A] border border-[#2A2A3E] rounded-xl p-1 gap-0.5">
            {["All","Settled","Owing","Overdue"].map(f => (
              <button key={f} onClick={() => setStatusFilter(f)}
                className={"text-xs font-medium px-3 py-1.5 rounded-lg transition-all " +
                  (statusFilter===f ? "bg-[#2A2A3E] text-white" : "text-[#6B7280] hover:text-[#D1D5DB]")}>
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center bg-[#13131A] border border-[#2A2A3E] rounded-xl p-1 gap-0.5">
            {["All","EFT","Account","Card","Cash"].map(f => (
              <button key={f} onClick={() => setPayFilter(f)}
                className={"text-xs font-medium px-3 py-1.5 rounded-lg transition-all " +
                  (payFilter===f ? "bg-[#2A2A3E] text-white" : "text-[#6B7280] hover:text-[#D1D5DB]")}>
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1F2233]">
                {["Invoice","Client","Date","Skips","Hire","Payment","Driver","Amount","Owing","Status"].map(h => (
                  <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-widest text-[#4B5563] pb-3 px-3 font-mono">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => {
                const status = getStatus(inv);
                const owing = inv.amount - inv.banked;
                return (
                  <tr key={inv.id} className="border-b border-[#1A1A28] last:border-0 hover:bg-[#13131A] transition-colors">
                    <td className="py-3.5 px-3 text-[11px] font-mono text-[#6B7280]">{inv.id}</td>
                    <td className="py-3.5 px-3 text-sm font-medium text-white">{inv.client}</td>
                    <td className="py-3.5 px-3 text-xs font-mono text-[#6B7280]">{inv.date}</td>
                    <td className="py-3.5 px-3 text-xs text-[#9BA3B7]">{inv.items}</td>
                    <td className="py-3.5 px-3"><span className="text-xs px-2 py-0.5 rounded-md font-mono" style={{ background:hireColors[inv.hire]+"18", color:hireColors[inv.hire] }}>{inv.hire}</span></td>
                    <td className="py-3.5 px-3"><span className="text-xs px-2 py-0.5 rounded-md font-mono" style={{ background:payColors[inv.payment]+"18", color:payColors[inv.payment] }}>{inv.payment}</span></td>
                    <td className="py-3.5 px-3 text-xs text-[#6B7280]">{inv.driver}</td>
                    <td className="py-3.5 px-3 text-sm font-semibold text-[#C97010] font-mono">R {inv.amount.toLocaleString("en-ZA")}</td>
                    <td className="py-3.5 px-3 text-sm font-mono" style={{ color: owing>0?"#F87171":"#00E676" }}>{owing>0?"R "+owing.toLocaleString("en-ZA"):"—"}</td>
                    <td className="py-3.5 px-3"><StatusBadge status={status} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {invoices.length === 0 && (
            <div className="py-12 text-center text-[#4B5563] text-sm">No invoices match your filters.</div>
          )}
        </div>
      </div>
    </div>
  );
}
