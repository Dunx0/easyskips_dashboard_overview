"use client";

import { useState } from "react";
import {
  TrendingUp, TrendingDown, AlertCircle, CheckCircle2,
  Truck, Clock, Wrench, ArrowUpRight, ArrowDownRight,
  CalendarDays, Filter, Download, RefreshCw, MoreHorizontal,
  CreditCard, Wallet, Users, BarChart3, Zap
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell,
  AreaChart, Area
} from "recharts";

// ── MOCK DATA ──────────────────────────────────────────────
const cashflowData = [
  { day: "1",  invoiced: 4200,  collected: 3800 },
  { day: "3",  invoiced: 5100,  collected: 4200 },
  { day: "5",  invoiced: 4800,  collected: 4600 },
  { day: "7",  invoiced: 7200,  collected: 5800 },
  { day: "9",  invoiced: 6400,  collected: 5200 },
  { day: "11", invoiced: 8100,  collected: 6900 },
  { day: "13", invoiced: 7600,  collected: 6400 },
  { day: "15", invoiced: 9200,  collected: 7800 },
  { day: "17", invoiced: 8400,  collected: 7200 },
  { day: "19", invoiced: 10100, collected: 8600 },
  { day: "21", invoiced: 9600,  collected: 8200 },
  { day: "23", invoiced: 11200, collected: 9400 },
  { day: "25", invoiced: 10800, collected: 9100 },
  { day: "27", invoiced: 12400, collected: 10600 },
  { day: "30", invoiced: 11800, collected: 10200 },
];

const revenueMonthly = [
  { month: "Jan", rev: 42000, cost: 28000 },
  { month: "Feb", rev: 38000, cost: 25000 },
  { month: "Mar", rev: 51000, cost: 31000 },
  { month: "Apr", rev: 47000, cost: 29000 },
  { month: "May", rev: 63000, cost: 38000 },
  { month: "Jun", rev: 58000, cost: 35000 },
  { month: "Jul", rev: 71000, cost: 42000 },
  { month: "Aug", rev: 75534, cost: 44000 },
];

const fleetDonutData = [
  { name: "Deployed",    value: 38, color: "#00E676" },
  { name: "Available",   value: 12, color: "#7C5CFC" },
  { name: "Maintenance", value: 2,  color: "#F87171" },
];

const skipMixData = [
  { name: "6m³",  value: 45, color: "#C97010" },
  { name: "9m³",  value: 28, color: "#7C5CFC" },
  { name: "3m³",  value: 18, color: "#2DD4BF" },
  { name: "2m³",  value: 9,  color: "#F472B6" },
];

const recentInvoices = [
  { id: "INV-0291", client: "Buco Cash",      amount: "R 1,350", status: "Settled",  date: "May 28", skip: "6m³ ×3" },
  { id: "INV-0290", client: "Euro Sales",     amount: "R 1,600", status: "Owing",    date: "May 26", skip: "6m³ ×2, 2m³ ×1" },
  { id: "INV-0289", client: "Shelly Park",    amount: "R 2,700", status: "Settled",  date: "May 22", skip: "6m³ ×4" },
  { id: "INV-0288", client: "Willie EFT",     amount: "R 2,250", status: "Settled",  date: "May 18", skip: "6m³ ×5" },
  { id: "INV-0287", client: "Eloftus Lodge",  amount: "R 1,200", status: "Overdue",  date: "Apr 28", skip: "9m³ ×1" },
  { id: "INV-0286", client: "Lesego Builds",  amount: "R 850",   status: "Settled",  date: "Apr 15", skip: "3m³ ×2" },
];

const drivers = [
  { name: "Joe",    jobs: 14, rev: "R 8,200", util: 78, trend: "up"   },
  { name: "Tsepho", jobs: 11, rev: "R 7,100", util: 65, trend: "up"   },
  { name: "Kagiso", jobs: 13, rev: "R 6,900", util: 71, trend: "down" },
  { name: "James",  jobs: 9,  rev: "R 5,400", util: 58, trend: "up"   },
  { name: "Oom WP", jobs: 12, rev: "R 6,100", util: 82, trend: "up"   },
];

const PERIODS = ["Daily", "Weekly", "Monthly", "Yearly"];

// ── HELPERS ───────────────────────────────────────────────
const R = n => "R " + Number(n).toLocaleString("en-ZA", { minimumFractionDigits: 2 });
const Rk = n => n >= 1000 ? "R " + (n / 1000).toFixed(1) + "k" : "R " + n;

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-xl px-4 py-3 shadow-2xl">
      <p className="text-xs text-[#6B7280] mb-2">Day {label}</p>
      {payload.map(p => (
        <p key={p.name} className="text-sm font-semibold" style={{ color: p.color }}>
          {p.name}: {Rk(p.value)}
        </p>
      ))}
    </div>
  );
}

function StatusBadge({ status }) {
  const cfg = {
    Settled: "bg-[#00E676]/10 text-[#00E676]",
    Owing:   "bg-[#FBBF24]/10 text-[#FBBF24]",
    Overdue: "bg-[#F87171]/10 text-[#F87171]",
  };
  return (
    <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg ${cfg[status] || "bg-[#2A2A3E] text-[#6B7280]"}`}>
      {status}
    </span>
  );
}

export default function DashboardPage() {
  const [period, setPeriod] = useState("Monthly");
  const now = new Date();
  const dateStr = now.toLocaleDateString("en-ZA", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  const totalUtil = 75;

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto fade-up">

      {/* ── PAGE HEADER ── */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Executive Overview</h1>
          <p className="text-sm text-[#6B7280] mt-1 flex items-center gap-2">
            <CalendarDays size={13} />
            {dateStr} · Monthly performance tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Period pills */}
          <div className="flex items-center bg-[#1C1C26] border border-[#2A2A3E] rounded-xl p-1 gap-0.5">
            {PERIODS.map(p => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`text-xs font-medium px-3.5 py-2 rounded-lg transition-all duration-200
                  ${period === p
                    ? "bg-[#2A2A3E] text-white shadow"
                    : "text-[#6B7280] hover:text-[#D1D5DB]"}`}
              >
                {p}
              </button>
            ))}
          </div>
          <button className="p-2.5 bg-[#1C1C26] border border-[#2A2A3E] rounded-xl text-[#6B7280] hover:text-white transition-colors">
            <Download size={16} />
          </button>
          <button className="p-2.5 bg-[#1C1C26] border border-[#2A2A3E] rounded-xl text-[#6B7280] hover:text-white transition-colors">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* ── KPI CARDS ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Invoiced */}
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 hover:border-[#3A3A5E] transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#C97010]/15 flex items-center justify-center">
                <CreditCard size={15} className="text-[#C97010]" />
              </div>
              <span className="text-sm text-[#9BA3B7]">Total Invoiced</span>
            </div>
            <span className="text-xs text-[#00E676] bg-[#00E676]/10 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
              <TrendingUp size={11} /> +15.0%
            </span>
          </div>
          <p className="text-3xl font-bold tracking-tight text-white mb-1">R 75,534</p>
          <p className="text-xs text-[#6B7280]">vs <span className="text-[#9BA3B7]">R 65,681</span> last month</p>
          <div className="mt-4 h-[3px] bg-[#2A2A3E] rounded-full overflow-hidden">
            <div className="h-full w-[78%] bg-gradient-to-r from-[#C97010] to-[#E88B1A] rounded-full" />
          </div>
        </div>

        {/* Cash Collected */}
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 hover:border-[#3A3A5E] transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#00E676]/10 flex items-center justify-center">
                <Wallet size={15} className="text-[#00E676]" />
              </div>
              <span className="text-sm text-[#9BA3B7]">Cash Collected</span>
            </div>
            <span className="text-xs text-[#00E676] bg-[#00E676]/10 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
              <TrendingUp size={11} /> +5.5%
            </span>
          </div>
          <p className="text-3xl font-bold tracking-tight text-white mb-1">R 60,786</p>
          <p className="text-xs text-[#6B7280]"><span className="text-[#00E676] font-semibold">80.5%</span> collection rate this month</p>
          <div className="mt-4 h-[3px] bg-[#2A2A3E] rounded-full overflow-hidden">
            <div className="h-full w-[80%] bg-gradient-to-r from-[#00E676] to-[#10B981] rounded-full" />
          </div>
        </div>

        {/* Outstanding */}
        <div className="bg-[#1C1C26] border border-[#F87171]/20 rounded-2xl p-5 hover:border-[#F87171]/40 transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#F87171]/10 flex items-center justify-center">
                <AlertCircle size={15} className="text-[#F87171]" />
              </div>
              <span className="text-sm text-[#9BA3B7]">Outstanding</span>
            </div>
            <span className="text-xs text-[#F87171] bg-[#F87171]/10 px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1">
              <TrendingDown size={11} /> +2.1%
            </span>
          </div>
          <p className="text-3xl font-bold tracking-tight text-[#F87171] mb-1">R 14,748</p>
          <p className="text-xs text-[#6B7280]"><span className="text-[#F87171] font-semibold">6</span> open invoices · <span className="text-[#F87171]">2</span> overdue 60+ days</p>
          <div className="mt-4 h-[3px] bg-[#2A2A3E] rounded-full overflow-hidden">
            <div className="h-full w-[19%] bg-gradient-to-r from-[#F87171] to-[#EF4444] rounded-full" />
          </div>
        </div>
      </div>

      {/* ── FLEET STATUS ── */}
      <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-base font-semibold text-white">Fleet Status</h2>
            <p className="text-xs text-[#6B7280] mt-0.5">52 total containers · real-time snapshot</p>
          </div>
          <button className="text-xs text-[#7C5CFC] hover:text-[#A78BFA] transition-colors font-medium">
            View All →
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Deployed",         value: 38, icon: Truck,        color: "#00E676", bg: "#00E676" },
            { label: "Available in Yard",value: 12, icon: CheckCircle2, color: "#7C5CFC", bg: "#7C5CFC" },
            { label: "In Maintenance",   value: 2,  icon: Wrench,       color: "#F87171", bg: "#F87171" },
            { label: "Utilisation Rate", value: "75%", icon: BarChart3, color: "#FBBF24", bg: "#FBBF24" },
          ].map(s => (
            <div key={s.label} className="bg-[#13131A] rounded-xl p-4 border border-[#1F2233] hover:border-[#2A2A3E] transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: s.bg + "18" }}>
                  <s.icon size={17} style={{ color: s.color }} />
                </div>
                <span className="text-xs text-[#6B7280]">{s.label}</span>
              </div>
              <p className="text-2xl font-bold tracking-tight" style={{ color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── CHARTS ROW ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Cashflow Line Chart — 2/3 width */}
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base font-semibold text-white">Cashflow Projection</h2>
              <p className="text-xs text-[#6B7280] mt-0.5">Invoiced vs Collected · May 2026</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-[#9BA3B7]">
                <span className="w-3 h-[2px] rounded-full bg-[#C97010] inline-block" />
                Invoiced
              </span>
              <span className="flex items-center gap-1.5 text-[#9BA3B7]">
                <span className="w-3 h-[2px] rounded-full bg-[#00E676] inline-block" />
                Collected
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={cashflowData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gradInvoiced" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#C97010" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#C97010" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradCollected" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00E676" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#00E676" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "#4B5563", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#4B5563", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => `R${v/1000}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="invoiced" name="Invoiced" stroke="#C97010" strokeWidth={2.5} fill="url(#gradInvoiced)" dot={false} activeDot={{ r: 5, fill: "#C97010" }} />
              <Area type="monotone" dataKey="collected" name="Collected" stroke="#00E676" strokeWidth={2.5} fill="url(#gradCollected)" dot={false} activeDot={{ r: 5, fill: "#00E676" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Fleet Utilisation Donut — 1/3 width */}
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 flex flex-col">
          <div className="mb-4">
            <h2 className="text-base font-semibold text-white">Fleet Utilisation</h2>
            <p className="text-xs text-[#6B7280] mt-0.5">By container status</p>
          </div>
          <div className="flex-1 flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height={170}>
              <PieChart>
                <Pie data={fleetDonutData} cx="50%" cy="50%" innerRadius={52} outerRadius={75}
                  paddingAngle={3} dataKey="value" startAngle={90} endAngle={-270} strokeWidth={0}>
                  {fleetDonutData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#1C1C26", border: "1px solid #2A2A3E", borderRadius: 12 }}
                  itemStyle={{ color: "#F0F2F8", fontSize: 13 }} formatter={v => `${v} skips`} />
              </PieChart>
            </ResponsiveContainer>
            {/* Centre label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-white">75%</span>
              <span className="text-xs text-[#6B7280]">utilised</span>
            </div>
          </div>
          <div className="flex flex-col gap-2 mt-3">
            {fleetDonutData.map(d => (
              <div key={d.name} className="flex items-center gap-3 justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  <span className="text-sm text-[#9BA3B7]">{d.name}</span>
                </div>
                <span className="text-sm font-semibold text-white font-mono">{d.value} units</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── MONTHLY REVENUE BARS + SKIP MIX ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly Revenue Area */}
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base font-semibold text-white">Monthly Revenue</h2>
              <p className="text-xs text-[#6B7280] mt-0.5">Revenue vs Estimated Cost · 2026</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-[#9BA3B7]"><span className="w-3 h-[2px] bg-[#7C5CFC] inline-block rounded-full" />Revenue</span>
              <span className="flex items-center gap-1.5 text-[#9BA3B7]"><span className="w-3 h-[2px] bg-[#2DD4BF] inline-block rounded-full" />Cost</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueMonthly} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gradRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7C5CFC" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#7C5CFC" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradCost" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2DD4BF" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#2DD4BF" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2233" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#4B5563", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#4B5563", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={v => `R${v/1000}k`} />
              <Tooltip contentStyle={{ background: "#1C1C26", border: "1px solid #2A2A3E", borderRadius: 12 }}
                labelStyle={{ color: "#9BA3B7", fontSize: 12 }} itemStyle={{ color: "#F0F2F8", fontSize: 13 }}
                formatter={v => `R ${v.toLocaleString("en-ZA")}`} />
              <Area type="monotone" dataKey="rev"  name="Revenue" stroke="#7C5CFC" strokeWidth={2.5} fill="url(#gradRev)"  dot={false} activeDot={{ r: 5, fill: "#7C5CFC" }} />
              <Area type="monotone" dataKey="cost" name="Est. Cost" stroke="#2DD4BF" strokeWidth={2}   fill="url(#gradCost)" dot={false} activeDot={{ r: 4, fill: "#2DD4BF" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Skip Size Mix Donut */}
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5 flex flex-col">
          <div className="mb-4">
            <h2 className="text-base font-semibold text-white">Skip Revenue Mix</h2>
            <p className="text-xs text-[#6B7280] mt-0.5">By container size this month</p>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <ResponsiveContainer width="100%" height={150}>
              <PieChart>
                <Pie data={skipMixData} cx="50%" cy="50%" innerRadius={44} outerRadius={65}
                  paddingAngle={3} dataKey="value" strokeWidth={0}>
                  {skipMixData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#1C1C26", border: "1px solid #2A2A3E", borderRadius: 12 }}
                  itemStyle={{ color: "#F0F2F8", fontSize: 13 }} formatter={v => `${v}%`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {skipMixData.map(d => (
              <div key={d.name} className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                <span className="text-xs text-[#9BA3B7]">{d.name}</span>
                <span className="text-xs font-semibold text-white ml-auto font-mono">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── BOTTOM ROW: INVOICES TABLE + DRIVER LEADERBOARD ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Recent Invoices */}
        <div className="lg:col-span-2 bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-base font-semibold text-white">Recent Invoices</h2>
              <p className="text-xs text-[#6B7280] mt-0.5">Latest 6 transactions</p>
            </div>
            <button className="text-xs text-[#7C5CFC] hover:text-[#A78BFA] transition-colors font-medium">
              View All →
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1F2233]">
                  {["Invoice", "Client", "Amount", "Skip", "Date", "Status"].map(h => (
                    <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-widest text-[#4B5563] pb-3 px-2 font-mono">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentInvoices.map(inv => (
                  <tr key={inv.id} className="border-b border-[#1A1A28] last:border-0 hover:bg-[#13131A] transition-colors">
                    <td className="py-3.5 px-2 text-[11px] font-mono text-[#6B7280]">{inv.id}</td>
                    <td className="py-3.5 px-2 text-sm font-medium text-white">{inv.client}</td>
                    <td className="py-3.5 px-2 text-sm font-semibold text-[#C97010] font-mono">{inv.amount}</td>
                    <td className="py-3.5 px-2 text-xs text-[#6B7280] font-mono">{inv.skip}</td>
                    <td className="py-3.5 px-2 text-xs text-[#6B7280]">{inv.date}</td>
                    <td className="py-3.5 px-2"><StatusBadge status={inv.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Driver Leaderboard */}
        <div className="bg-[#1C1C26] border border-[#2A2A3E] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-base font-semibold text-white">Driver Leaderboard</h2>
              <p className="text-xs text-[#6B7280] mt-0.5">Top performers · this month</p>
            </div>
            <span className="text-[10px] bg-[#FBBF24]/10 text-[#FBBF24] px-2.5 py-1 rounded-lg font-semibold uppercase tracking-wider">
              Live
            </span>
          </div>
          <div className="flex flex-col gap-3">
            {drivers.map((d, i) => (
              <div key={d.name} className="flex items-center gap-3">
                <span className="text-sm w-5 text-center flex-shrink-0">
                  {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : <span className="text-xs text-[#4B5563] font-mono">#{i+1}</span>}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-medium text-white">{d.name}</span>
                    <span className="text-xs font-semibold text-[#C97010] font-mono">{d.rev}</span>
                  </div>
                  <div className="h-1.5 bg-[#13131A] rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${d.util}%`,
                        background: i === 0
                          ? "linear-gradient(90deg, #C97010, #E88B1A)"
                          : i === 1
                          ? "linear-gradient(90deg, #7C5CFC, #9B7CFC)"
                          : "linear-gradient(90deg, #2DD4BF, #34D399)"
                      }} />
                  </div>
                </div>
                <div className="flex flex-col items-end flex-shrink-0">
                  <span className="text-[11px] font-mono text-[#9BA3B7]">{d.util}%</span>
                  <span className="text-[10px] text-[#6B7280]">{d.jobs} jobs</span>
                </div>
              </div>
            ))}
          </div>

          {/* Total bonus estimate */}
          <div className="mt-5 pt-4 border-t border-[#1F2233]">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#6B7280]">Est. Total Bonus Payout</span>
              <span className="text-base font-bold text-[#00E676]">R 3,450</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
